# Argument Referee (Discord bot)

Type `/referee` after a fight. The bot reads the last N messages in the channel and posts a ruling:
winner, scores, strong points, logical fouls, and a closing line.

## Setup
1. Discord Developer Portal -> New Application -> Bot -> copy the token.
2. On the Bot page, enable **Message Content Intent**.
3. OAuth2 -> URL Generator: scopes `bot` + `applications.commands`; permissions
   View Channels, Read Message History, Send Messages, Embed Links. Open the URL to invite the bot.
4. `cp .env.example .env` and fill in both keys.
5. `pip install -r requirements.txt && python bot.py`

Slash commands can take up to an hour to appear globally the first time.

## Notes
- Messages are only read when someone runs `/referee`, then sent to the Claude API for judging.
  Tell your server this, and consider a one-line privacy note on your bot page.
- Cooldown is 30s per user. Change it in the decorator in `bot.py`.
- Cost is roughly one API call per ruling (up to ~12k characters of input).
